import { NextFunction, Request, Response } from "express";
import { AppDataSource } from "../data.source";
import { Product } from "../entities/Product";
import { error } from "node:console";
import { SubCategory } from "../entities/SubCategory";

export class AdminProductController {
  static async getAllProducts(req: Request, res: Response, next: NextFunction) {
    try {
      const { page = "1", limit = "20" } = req.query;
      const pageNum = Math.max(1, parseInt(page as string) || 1);
      const limitNum = Math.min(
        100,
        Math.max(1, parseInt(limit as string) || 20),
      );
      const skip = (pageNum - 1) * limitNum;

      const [products, total] = await AppDataSource.getRepository(Product)
        .createQueryBuilder("product")
        .leftJoinAndSelect("product.subCategory", "subCategory")
        .leftJoinAndSelect("subCategory.category", "category")
        .leftJoinAndSelect("category.productType", "productType")
        .orderBy("product.createdAt", "DESC")
        .skip(skip)
        .take(limitNum)
        .getManyAndCount();

      return res.status(200).json({
        data: products,
        meta: {
          total,
          page: pageNum,
          limit: limitNum,
          totalPages: Math.ceil(total / limitNum),
        },
      });
    } catch (err) {
      next(err);
    }
  }

  // static async createProduct(req: Request, res: Response, next: NextFunction) {
  //   try {
  //     if (!req.body) {
  //       return res
  //         .status(400)
  //         .json({ error: "Request body is undefined. Check middleware." });
  //     }

  //     const { name, description, price, stock, subCategoryId } = req.body;
  //     if (!name || !price || !stock || !subCategoryId) {
  //       return res
  //         .status(400)
  //         .json({ error: "name, price and subCategoryId are required" });
  //     }

  //     const priceNum = parseFloat(price);
  //     const stockNum = parseInt(stock ?? "0");

  //     if (isNaN(priceNum) || priceNum < 0) {
  //       return res.status(400).json({ error: "Price number isnt valid" });
  //     }

  //     if (isNaN(stockNum) || stockNum < 0) {
  //       return res.status(400).json({ error: "Stock number isnt valid" });
  //     }

  //     const subCategory = await AppDataSource.getRepository(
  //       SubCategory,
  //     ).findOneBy({
  //       sub_category_id: Number(subCategoryId),
  //     });
  //     if (!subCategory)
  //       return res.status(404).json({ error: "SubCategory not found" });

  //     const productRepo = await AppDataSource.getRepository(Product);
  //     const product = productRepo.create({
  //       name: name.trim(),
  //       description: description?.trim() ?? null,
  //       price: priceNum,
  //       stock: stockNum,
  //       subCategory,
  //       isActive: true,
  //     });

  //     await productRepo.save(product);
  //     return res
  //       .status(201)
  //       .json({ message: "Product created", product_id: product.product_id });
  //   } catch (err) {
  //     next(err);
  //   }
  // }

  static async createProduct(req: Request, res: Response, next: NextFunction) {
    try {
      console.log(">>> HIT createProduct");
      console.log(">>> body:", req.body);
      console.log(">>> file:", req.file);
      if (!req.body) {
        return res.status(400).json({
          error:
            "Request body missing. Ensure Content-Type is multipart/form-data.",
        });
      }

      console.log("Body:", req.body);
      console.log("File:", req.file);
      console.log("Content-Type:", req.headers["content-type"]);
      const { name, description, price, stock, subCategoryId } = req.body ?? {};

      if (!name || !price || !stock || !subCategoryId) {
        return res
          .status(400)
          .json({ error: "name, price, stock and subCategoryId are required" });
      }
      if (!req.file) console.log("File not found");

      const priceNum = Number(price);
      const stockNum = Number(stock ?? "0");

      if (isNaN(priceNum) || priceNum < 0)
        return res.status(400).json({ error: "Price is not valid" });
      if (isNaN(stockNum) || stockNum < 0)
        return res.status(400).json({ error: "Stock is not valid" });

      const subCategory = await AppDataSource.getRepository(
        SubCategory,
      ).findOneBy({
        sub_category_id: Number(subCategoryId),
      });
      if (!subCategory)
        return res.status(404).json({ error: "SubCategory not found" });

      // Read the uploaded file — will be null if no image was sent
      // const imagePath = req.file ? req.file.path.replace(/\\/g, "/") : null;

      const imagePath = req.file ? req.file.filename : null;
      const productRepo = AppDataSource.getRepository(Product);
      const product = productRepo.create({
        name: name.trim(),
        description: description?.trim() ?? null,
        price: priceNum,
        stock: stockNum,
        subCategory,
        isActive: true,
        imagePath,
      });

      await productRepo.save(product);
      return res
        .status(201)
        .json({ message: "Product created", product_id: product.product_id });
    } catch (err) {
      next(err);
    }
  }
  static async deleteProduct(req: Request, res: Response, next: NextFunction) {
    try {
      const productId = Number(req.params.productId);
      if (isNaN(productId))
        return res.status(400).json({ error: "Invalid productId" });

      const productRepo = AppDataSource.getRepository(Product);
      const product = await productRepo.findOneBy({ product_id: productId });
      if (!product)
        return res.status(400).json({ error: "product doesnt exist" });

      product.isActive = false;
      await productRepo.save(product);

      return res.status(200).json({ message: "Product deactivated" });
    } catch (err) {
      next(err);
    }
  }

  static async updateProduct(req: Request, res: Response, next: NextFunction) {
    try {
      const productID = Number(req.params.productID);
      if (isNaN(productID))
        return res.status(400).json({ error: "ProductID is invalid" });

      const productRepo = await AppDataSource.getRepository(Product);
      const product = await productRepo.findOne({
        where: { product_id: productID },
        relations: { subCategory: true },
      });

      if (!product) return res.status(400).json({ error: "Product not found" });

      const { name, description, price, stock, subCategoryId, isActive } =
        req.body;
      const imageFile = req.file;

      if (name !== undefined) product.name = name.trim();
      if (description !== undefined) product.description = description.trim();
      if (isActive !== undefined)
        product.isActive = isActive === "true" || isActive === true;

      if (price !== undefined) {
        const priceNum = parseFloat(price);
        if (isNaN(priceNum) || priceNum < 0) {
          return res
            .status(400)
            .json({ error: "price must be a positive number" });
        }
        product.price = priceNum;
      }

      if (stock !== undefined) {
        const stockNum = parseInt(stock);
        if (isNaN(stockNum) || stockNum < 0) {
          return res
            .status(400)
            .json({ error: "stock must be a non-negative integer" });
        }
        product.stock = stockNum;
      }

      if (subCategoryId !== undefined) {
        const subCategory = await AppDataSource.getRepository(
          SubCategory,
        ).findOneBy({
          sub_category_id: Number(subCategoryId),
        });
        if (!subCategory)
          return res.status(404).json({ error: "SubCategory not found" });
        product.subCategory = subCategory;
      }
      if (imageFile) {
        // Logic to delete the old file from disk could go here if desired
        product.imagePath = imageFile.path.replace(/\\/g, "/");
      }
      await productRepo.save(product);
      return res.status(200).json({ message: "Product updated", product });
    } catch (err) {
      next(err);
    }
  }
}
