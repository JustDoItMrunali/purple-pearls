// import { Component, inject, OnInit } from '@angular/core';
// import { ProductService } from '../product-service';
// import { map, Observable } from 'rxjs';
// import { AsyncPipe } from '@angular/common';
// import { ProductCard } from '../product-card/product-card';
// import { ProductFilter } from '../product-filter/product-filter';
// import { ProductType, SubCategory } from '../../models/taxonomy.model';

// @Component({
//   selector: 'app-product-list',
//   imports: [AsyncPipe, ProductCard, ProductFilter],
//   templateUrl: './product-list.html',
//   styleUrl: './product-list.css',
// })
// export class ProductList implements OnInit {
//   private productService = inject(ProductService);

//   productType$: Observable<ProductType[]> = this.productService.getProductType();
//   subCategories$: Observable<SubCategory[]> | null = null;
//   selectedSubCategoryId: number | null = null;
//   selectedTypeId: number | null = null;

//   product$ = this.productService.product$.pipe(
//     map((response) => {
//       if (!response) return null;
//       return {
//         ...response,
//         pages: Array.from({ length: response.meta.totalPages }, (_, i) => i + 1),
//       };
//     }),
//   );

//   ngOnInit(): void {
//     this.productService.getProducts({}).subscribe();
//   }

//   goToPage(page: number): void {
//     this.productService.getProducts({ page }).subscribe();
//   }

//   onSearch(term: string): void {
//     const trimmed = term.trim();
//     this.selectedSubCategoryId = null;
//     this.selectedTypeId = null;
//     this.subCategories$ = null;
//     this.productService.getProducts({ q: trimmed, page: 1 }).subscribe();
//   }

//   onTypeClick(typeId: number): void {
//     this.selectedTypeId = typeId;
//     this.selectedSubCategoryId = null;
//     this.subCategories$ = this.productService.getProductSubCategory(typeId);
//     this.productService.getProducts({ typeId, page: 1 }).subscribe();
//   }

//   onSubCategoryClick(subCategoryId: number): void {
//     this.selectedSubCategoryId = subCategoryId;
//     this.productService.getProducts({ subCategoryId, page: 1 }).subscribe();
//   }
// }

import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { ProductService } from '../product-service';
import { map, Observable, Subject, debounceTime, distinctUntilChanged, takeUntil } from 'rxjs';
import { AsyncPipe, CommonModule } from '@angular/common';
import { ProductCard } from '../product-card/product-card';
import { ProductType, SubCategory, Category } from '../../models/taxonomy.model';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-list',
  imports: [AsyncPipe, CommonModule, ProductCard, FormsModule],
  templateUrl: './product-list.html',
  styleUrl: './product-list.css',
})
export class ProductList implements OnInit, OnDestroy {
  private productService = inject(ProductService);
  private destroy$ = new Subject<void>();
  private searchSubject = new Subject<string>();

  productTypes$: Observable<ProductType[]> = this.productService.getProductType();
  subCategories: SubCategory[] = [];

  product$ = this.productService.product$.pipe(
    map((response) => {
      if (!response) return null;
      return {
        ...response,
        pages: Array.from({ length: response.meta.totalPages }, (_, i) => i + 1),
      };
    }),
  );

  searchTerm = '';
  selectedTypeId: number | null = null;
  selectedSubCategoryId: number | null = null;
  currentPage = 1;

  ngOnInit(): void {
    this.productService.getProducts({}, true).subscribe();

    this.searchSubject
      .pipe(debounceTime(350), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe((term) => {
        this.currentPage = 1;
        this.productService
          .getProducts(
            {
              q: term || undefined,
              subCategoryId: this.selectedSubCategoryId || undefined,
              typeId: this.selectedTypeId || undefined,
              page: 1,
            },
            true,
          )
          .subscribe();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onSearchInput(value: string): void {
    this.searchTerm = value;
    this.searchSubject.next(value.trim());
  }

  onSearchEnter(): void {
    this.searchSubject.next(this.searchTerm.trim());
  }

  onTypeClick(typeId: number): void {
    if (this.selectedTypeId === typeId) {
      this.clearFilters();
      return;
    }
    this.selectedTypeId = typeId;
    this.selectedSubCategoryId = null;
    this.subCategories = [];
    this.currentPage = 1;

    this.productService.getProductCategory(typeId).subscribe((res: any) => {
      const categories: Category[] = res.categories ?? res;
      if (!categories.length) return;

      let loaded = 0;
      const allSubs: SubCategory[] = [];
      categories.forEach((cat) => {
        this.productService.getProductSubCategory(cat.category_id).subscribe((subs: any) => {
          const subList: SubCategory[] = subs.subCategories ?? subs;
          allSubs.push(...subList);
          loaded++;
          if (loaded === categories.length) {
            this.subCategories = allSubs.sort((a, b) => a.name.localeCompare(b.name));
          }
        });
      });
    });

    this.productService
      .getProducts({ typeId, q: this.searchTerm || undefined, page: 1 }, true)
      .subscribe();
  }

  onSubCategoryClick(subCategoryId: number): void {
    if (this.selectedSubCategoryId === subCategoryId) {
      this.selectedSubCategoryId = null;
      this.productService
        .getProducts(
          { typeId: this.selectedTypeId!, q: this.searchTerm || undefined, page: 1 },
          true,
        )
        .subscribe();
      return;
    }
    this.selectedSubCategoryId = subCategoryId;
    this.currentPage = 1;
    this.productService
      .getProducts({ subCategoryId, q: this.searchTerm || undefined, page: 1 }, true)
      .subscribe();
  }

  goToPage(page: number): void {
    this.currentPage = page;
    this.productService
      .getProducts(
        {
          page,
          q: this.searchTerm || undefined,
          typeId: this.selectedTypeId || undefined,
          subCategoryId: this.selectedSubCategoryId || undefined,
        },
        true,
      )
      .subscribe();
  }

  get selectedSubCategoryName(): string | null {
    if (!this.selectedSubCategoryId) return null;
    return (
      this.subCategories.find((s) => s.sub_category_id === this.selectedSubCategoryId)?.name ?? null
    );
  }

  clearFilters(): void {
    this.searchTerm = '';
    this.selectedTypeId = null;
    this.selectedSubCategoryId = null;
    this.subCategories = [];
    this.currentPage = 1;
    this.productService.getProducts({}, true).subscribe();
  }
}
